// Cart Model
export class Cart {
    public orderId: string='';
    public productId: number=0;
    public userId: string='';
    public productName: string='';
    public quantity: number=0;
    public dateOfPurchase: string='';
    public price: number=0;
    public totalPrice: number=0;
}

